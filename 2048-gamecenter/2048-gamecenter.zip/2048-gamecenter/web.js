// Express initialization
var express = require('express');
//var app = express(express.logger());
var app = express();


var bodyParser = require('body-parser');
app.use(bodyParser());

//var dataBase;

app.set('title', '2048_scores');
app.set('port', process.env.PORT || 3000);

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scores';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

//app.use(express.json());
//app.use(express.urlencoded());
//app.use(express.bodyParser());


app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

/*app.get('/', function (request, response) {
	
		db.collection('NAME_OF_YOUR_COLLECTON_HERE...', function(er, collection) {
			collection.find()...
	
	response.set('Content-Type', 'text/html');
	response.send('<p>Hi!</p>');
});

app.get('/data.json', function(request, response) {
	response.set('Content-Type', 'text/json');
	response.send('{"status":"good"}');
});

app.get('/fool', function(request, response) {
	response.set('Content-Type', 'text/html');
	response.send(500, 'Something broke!');
});*/


app.get('/', function (request, response){
// print the scores nicely and in order like not just in JSON
	db.collection('scores', function (er, collection){
		collection.find().sort({score: -1}).toArray(function (err, retData){
			response.set('Content-Type', 'text/html');
			var innerhtml = "<!DOCTYPE html> <html> <head> <title> 2048 Game Center </title> <meta charset='UTF-8'> </head> <body> ";
			innerhtml += "<h1> 2048 Scores </h1>";

			for (var i=0; i<retData.length; i++){
				innerhtml = innerhtml + "<p>" + retData[i].username + " "
				 + retData[i].score + " " + retData[i].created_at + "</p>";
			}
			innerhtml = innerhtml + " </p> </body> </html>";

		
			response.send(innerhtml);

		}); 
	});

});

app.get('/scores.json', function (request, response){
//returns JSON string for a single username
	

	db.collection('scores', function (er, collection){
	//dataBase('scores', function (er, collection){
		var username = "";
		username = request.query.username; //???
		var scores = new Array();
		var debug = 'uninitialized';
		if (username != ""){
			debug = 'inside before collection.find()';
			
			scores = collection.find({"username":username}).sort({score: -1}).toArray(function (err, x){
			//scores = collection.find({"username":username}).toArray(function (err, x){
			response.send(x);
			//does something go here?
			//console.log('recieved some stuff');
			debug = 'recieved some stuff';

			});
		}
		else{
		//	console.log("didn't recieve stuff");
			debug = 'recieved no stuff';
			response.send("Nothing recieved");
		}
		/*var temp = collection.find().toArray(function (err, x){
			});

		response.set('Content-Type', 'text/html');
		response.send(temp);
		//response.send(debug);
		stringscores = JSON.stringify(scores);*/
		//response.send(username);

		//response.send(stringscores);


	});
});

app.post('/submit.json', function (request, response){
// submits final score and grid for terminated game
	db.collection('scores', function (er, collection){
		var username = null;
		var score = -1;
		var grid = null;

		username = request.body.username;
		score = Number(request.body.score);
		grid = request.body.grid;

		if (username != null && score != -1 && grid != null){
			var today = new Date();

			var minutes = today.getMinutes();
			if (minutes < 10){
				minutes = '0'+minutes;
			}

			var timestamp = (today.getMonth()+1) + "/" + (today.getDate()+1) 
			+ "/" + (today.getFullYear()) + " " + (today.getHours()) + ":" +
			minutes;

			collection.insert({"score": score, "username": username, "grid": grid, "created_at": timestamp}, function(err, req){
				console.log("Inserted to the collection");

			});
			response.send("Here is a response");
		} else {
			response.send(500, "Stuff's not working");
		}

	});

});
// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);
