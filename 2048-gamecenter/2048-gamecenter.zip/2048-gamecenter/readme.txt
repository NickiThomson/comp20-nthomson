readme

Identify what aspects of the work have been correctly implemented and what have not.

Time stamp may have problems when the minutes are under 10, due to the times this was being tested, it was not tested.

Identify anyone with whom you have collaborated or discussed the assignment.

Win Halelamien 
Peter Paleologopoulos
Emma Posamentier

Say approximately how many hours you have spent completing the assignment.

10

(For this assignment) Explain how the score and grid are stored in the 2048 game. That is, in what object and in what file(s)?

Grid is stored in an object, the fuctions of which are in grid.js
The best score is a variable in the local_storage.js file

(For this assignment) Explain the modifications, including name of the source file(s), that you had to make in order to send the final score and grid to your web application.

In the function GameManager.prototype.move

the if statement which originally said:

    if (!this.movesAvailable()) {
      this.over = true; // Game over!
    } 

Was changed to include

    if (!this.movesAvailable()) {
    var grid2send = JSON.stringify(this.grid.serialize());
    var scores2send = this.score;
    var username = window.prompt("Please enter your username", "user")
    $.post("http://infinite-stream-2374.herokuapp.com/submit.json", {username: username, score: scores2send, grid: grid2send } );
      this.over = true; // Game over!
    }